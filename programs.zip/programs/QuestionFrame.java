package programs;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.Timer;

public class QuestionFrame extends Thread implements ActionListener{
	static JFrame f;
	JLabel questionNumber,question;
	static JLabel time;
	JRadioButton r1,r2,r3,r4;
	static JButton next;
	JButton quit;
	ButtonGroup bg;
	QuestionsFile qJava = new QuestionsFile();
	int loop = 0;
	boolean selected = false;
	static int seconds = ShowDetails.time;
	String cnt = "", lang = "";
	static List<String> questionsList = new ArrayList<String>();
	List<String> correctList = new ArrayList<String>();
	static ArrayList<String[]> arrayList = new ArrayList<String[]>();
	String[] ch;
	List<String> answerList = new ArrayList<String>();
	Timer timer;

	public QuestionFrame(String count,String language){
		lang = language;
		cnt = count; 
		String q = "";
		questionsList = qJava.QuestionsList(Integer.parseInt(count),language);
		q = questionsList.get(loop++);
		arrayList = qJava.getOptions();
		correctList = qJava.getAnswers();
		ch = arrayList.get(0);
		timer = new Timer(1000, new callThread());
		timer.start();
		Questions(q, 0,ch);
	}
	public QuestionFrame() {
	}
	public void Questions(String q,int flag,String[] arrayList){
		f = new JFrame("QUESTIONS");
		f.setBounds(500,300,700,350);
		f.setLayout(null);

		questionNumber = new JLabel("QUESTION : " + (flag + 1) + " / " + cnt);
		questionNumber.setBounds(20,20,200,25);
		questionNumber.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		f.add(questionNumber);

		question = new JLabel(q);
		question.setBounds(20,70,650,25);
		question.setFont(new Font("Times New Roman", Font.BOLD, 15));
		f.add(question);
		time = new JLabel();
		time.setBounds(500,20,200,25);
		time.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		f.add(time);

		r1= new JRadioButton(arrayList[0]);
		r1.setBounds(120,110,500,25);
		r1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		f.add(r1);

		r2= new JRadioButton(arrayList[1]);
		r2.setBounds(120,140,500,25);
		r2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		f.add(r2);

		r3= new JRadioButton(arrayList[2]);
		r3.setBounds(120,170,500,25);
		r3.setFont(new Font("Times New Roman", Font.BOLD, 15));
		f.add(r3);

		r4= new JRadioButton(arrayList[3]);
		r4.setBounds(120,200,500,25);
		r4.setFont(new Font("Times New Roman", Font.BOLD, 15));
		f.add(r4);
		
		r1.setOpaque(false);
		r2.setOpaque(false);
		r3.setOpaque(false);
		r4.setOpaque(false);
		bg = new ButtonGroup();
		bg.add(r1);
		bg.add(r2);
		bg.add(r3);
		bg.add(r4);

		next = new JButton("NEXT>>>");
		next.setBounds(450,250,100,25);
		next.addActionListener(this);
		f.add(next);

		quit = new JButton("QUIT");
		quit.setBounds(20,250,75,25);
		quit.addActionListener(this);
		f.add(quit);

		f.getContentPane().setBackground(new Color(230, 255, 179));
		f.setVisible(true);
	}
	public void result(boolean b){
		if(b) JOptionPane.showMessageDialog(null, "TIME UP !!! \n CLICK SUBMIT TO SEE THE RESULT");
	}
	@Override
	public void actionPerformed(ActionEvent e) {				
		if(e.getActionCommand().equals("QUIT")){
			timer.stop();
			f.dispose();
		}
		if(e.getActionCommand().equals("NEXT>>>")){
			selected = false;
			for(Enumeration<AbstractButton> buttons = bg.getElements();buttons.hasMoreElements();){
				AbstractButton rb = buttons.nextElement();
				if(rb.isSelected()){
					selected = true;
					answerList.add(rb.getText());
					break;
				}
			}
			if(! selected){
				answerList.add("");
			}
			bg.clearSelection();
			ch = arrayList.get(loop);
			if(loop < questionsList.size()){
				question.setText(questionsList.get(loop++));
				r1.setText(ch[0]);
				r2.setText(ch[1]);
				r3.setText(ch[2]);
				r4.setText(ch[3]);
				questionNumber.setText("QUESTION : " + loop + " / " + cnt);
			}
			if(questionsList.size() == loop)
				next.setText("SUBMIT");
		}
		if(e.getActionCommand().equals("SUBMIT")){
			timer.stop();
			selected = false;
			for(Enumeration<AbstractButton> buttons = bg.getElements();buttons.hasMoreElements();){
				AbstractButton rb = buttons.nextElement();
				if(rb.isSelected()){
					selected = true;
					answerList.add(rb.getText());
					break;
				}
			}
			if(!selected){
				answerList.add("");
			}
			if(loop != Integer.parseInt(cnt)){
				while(loop++ != Integer.parseInt(cnt))
					answerList.add("");
			}
			f.dispose();
			new ResultPage(lang,answerList,correctList);
		}
	}
}
class callThread implements ActionListener{
	QuestionFrame qf = new QuestionFrame();
	int count = QuestionFrame.seconds;
	@Override
	public void actionPerformed(ActionEvent e) {
		if(count <= 10){
			QuestionFrame.time.setForeground(Color.RED);
		}
		if(count >= 0){
			QuestionFrame.time.setText(count-- + " SECONDS");
		}else{
			QuestionFrame.next.setText("SUBMIT");
			((Timer) e.getSource()).stop();
			if(!QuestionFrame.f.isActive()){
				qf.result(false);
			}else{
				qf.result(true);
			}
		}
	}
}
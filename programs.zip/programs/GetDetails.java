package programs;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;

public class GetDetails implements ActionListener{
	static JFrame frame;
	JLabel label,l1,l2,l3,l4,l5;
	JButton b1,b2;
	JRadioButton r1,r2,r3,r4,r5;
	ButtonGroup bg;
	String lang = "";
	public GetDetails(String language){
		lang = language;
		frame = new JFrame(language + " ONLINE TEST");
		frame.setBounds(500,300,350,300);
		frame.setLayout(null);

		label = new JLabel("Select number of questions");
		label.setBounds(20,10,300,25);
		label.setFont(new Font("Lucida Console", Font.BOLD, 15));
		frame.add(label);

		r1= new JRadioButton("10",true);
		r1.setBounds(120,40,50,25);
		r1.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		r1.setOpaque(false);
		frame.add(r1);

		r2= new JRadioButton("20");
		r2.setBounds(120,70,50,25);
		r2.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		r2.setOpaque(false);
		frame.add(r2);

		r3= new JRadioButton("30");
		r3.setBounds(120,100,50,25);
		r3.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		r3.setOpaque(false);
		frame.add(r3);

		r4= new JRadioButton("40");
		r4.setBounds(120,130,50,25);
		r4.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		r4.setOpaque(false);
		frame.add(r4);

		r5= new JRadioButton("50");
		r5.setBounds(120,160,50,25);
		r5.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		r5.setOpaque(false);
		frame.add(r5);

		bg = new ButtonGroup();
		bg.add(r1);
		bg.add(r2);
		bg.add(r3);
		bg.add(r4);
		bg.add(r5);

		b1 = new JButton("OK");
		b1.setBounds(210,210,70,25);
		b1.setBackground(new Color(255, 255, 255));
		frame.add(b1);
		b1.addActionListener(this);

		b2 = new JButton("MAIN MENU");
		b2.setBounds(30,210,100,25);
		b2.setBackground(new Color(255, 255, 255));
		frame.add(b2);
		b2.addActionListener(this);
		
		frame.getContentPane().setBackground(new Color(230, 255, 179));
		frame.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		String selection ="";
		if(e.getActionCommand().equals("MAIN MENU")){
			frame.dispose();
		}
		if(e.getActionCommand().equals("OK")){		
			for(Enumeration<AbstractButton> buttons = bg.getElements();buttons.hasMoreElements();){
				AbstractButton rb = buttons.nextElement();
				if(rb.isSelected()){
					selection = rb.getText();
					break;
				}
			}
			frame.dispose();
			new ShowDetails(selection,lang);
		}
	}
}

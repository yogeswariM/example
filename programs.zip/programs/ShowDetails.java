package programs;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ShowDetails implements ActionListener{
	JFrame frame;
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11;
	JButton b1,b2;
	static String count="",lang="";
	static int time = 0;
	public ShowDetails(String selection,String language){
		count = selection;
		lang =language;
		frame = new JFrame("DETAILS");
		frame.setBounds(500,300,400,350);
		frame.setLayout(null);
		
		l1 = new JLabel("TEST NAME ");
		l1.setBounds(30,30,150,25);
		frame.add(l1);
		l2 = new JLabel(": \t"+ language + " ONLINE TEST");
		l2.setBounds(200,30,150,25);
		frame.add(l2);
		l3 = new JLabel("NO. OF QUESTIONS ");
		l3.setBounds(30,60,150,25);
		frame.add(l3);
		l4 = new JLabel(": \t"+ selection);
		l4.setBounds(200,60,150,25);
		frame.add(l4);
		l5 = new JLabel("CORRECT ANSWER ");
		l5.setBounds(30,90,150,25);
		frame.add(l5);
		l6 = new JLabel(": \t1 MARK");
		l6.setBounds(200,90,150,25);
		frame.add(l6);
		l7 = new JLabel("WRONG ANSWER ");
		l7.setBounds(30,120,150,25);
		frame.add(l7);
		l8 = new JLabel(": \t-1 MARK");
		l8.setBounds(200,120,150,25);
		frame.add(l8);
		l9 = new JLabel("TIME TO FINISH ");
		l9.setBounds(30,150,150,25);
		frame.add(l9);
		time = (Integer.parseInt(selection)*6);
		l10 = new JLabel(": " + time + " SECONDS");
		l10.setBounds(200,150,150,25);
		frame.add(l10);
		l11 = new JLabel("\" YOU CANNOT GO BACK TO PREVIOUS QUESTION \"");
		l11.setBounds(40,200,330,25);
		frame.add(l11);
		
		b1 = new JButton("GO");
		b1.setBounds(250,250,75,25);
		frame.add(b1);
		b1.addActionListener(this);
		b2 = new JButton("BACK");
		b2.setBounds(30,250,75,25);
		frame.add(b2);
		b2.addActionListener(this);
		
		frame.getContentPane().setBackground(new Color(230, 255, 179));
		frame.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("BACK")){
			frame.dispose();
			GetDetails.frame.setVisible(true);
		}
		if(e.getActionCommand().equals("GO")){
			frame.dispose();
			new QuestionFrame(count,lang);
		}
	}
}

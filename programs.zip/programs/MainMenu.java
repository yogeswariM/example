package programs;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JButton;

public class MainMenu implements ActionListener{
	JFrame mainFrame;
	JButton button1,button2,button3;
	public MainMenu(){
		mainFrame = new JFrame("ONLINE TEST");
		mainFrame.setBounds(500,300,400,200);
		mainFrame.setLayout(null);

		button1 = new JButton("C");
		button1.setBounds(40,60,85,25);
		button1.setBackground(new Color(255, 255, 255));
		button1.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		mainFrame.add(button1);
		button1.addActionListener(this);

		button2 = new JButton("C++");
		button2.setBounds(150,60,85,25);
		button2.setBackground(new Color(255, 255, 255));
		button2.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		mainFrame.add(button2);
		button2.addActionListener(this);

		button3 = new JButton("JAVA");
		button3.setBounds(260,60,85,25);
		button3.setBackground(new Color(255, 255, 255));
		button3.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
		mainFrame.add(button3);
		button3.addActionListener(this);

		mainFrame.getContentPane().setBackground(new Color(230, 255, 179));
		mainFrame.setVisible(true);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("C")){
			new GetDetails("C");
		}
		if(e.getActionCommand().equals("C++")){
			new GetDetails("C++");
		}
		if(e.getActionCommand().equals("JAVA")){
			new GetDetails("JAVA");
		}
	}
	public static void main(String args[]){
		new MainMenu();
	}
}

package programs;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Java8Tester {
	public static void main(String args[]){
		Java8Tester jt = new Java8Tester();
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
		System.out.println("Print all numbers:");
		eval(list, n->true);

		System.out.println("Print even numbers:");
		eval(list, n-> n%2 == 0 );

		System.out.println("Print numbers greater than 3:");
		eval(list, n-> n > 3 );
		System.out.println("List of values :");
		list.forEach(System.out::println);

		Operation op1 = (int a,int b) -> a + b;
		Operation op2 = (a,b) -> a - b;
		Operation op3 = (a,b) -> a * b;
		Operation op4 = (a,b) -> {return a / b;};
		Operation op5 = (a,b) -> {return a % b;};
		Message msg = (message) -> System.out.print("Welcome "+message);
		msg.sayMessage("JAVA 8");
		System.out.print("\n Value :" + jt.operate(50, 20, op1));
		System.out.print("\n Value :" + jt.operate(50, 20, op2));
		System.out.print("\n Value :" + jt.operate(50, 20, op3));
		System.out.print("\n Value :" + jt.operate(50, 20, op4));
		System.out.print("\n Value :" + jt.operate(50, 25, op5));
		
		
		List<String> strings = Arrays.asList("abc", "", "bc", "efg", "abcd","", "jkl");
		long count = strings.stream().filter(string -> string.contains("b")).count();
		System.out.println("\n Empty strings count : " + count);
		List<String> coll = strings.stream().filter(string -> string.contains("c")).collect(Collectors.toList());
		System.out.println("\n List of values :" + coll);
		
		List<Integer> numbers = Arrays.asList(30,20,50,2,25,21,15,52,5,8,750,95);
		numbers.stream().sorted().forEach(System.out::println);
		int c = (int) numbers.stream().filter(n -> (n % 2 == 0) && (n % 4 == 0)).count();
		System.out.print("\n Numbers : " + numbers + "\n Count : " + c);
		numbers.stream().filter(n -> n % 2 == 0).sorted().forEach(System.out::println);
		System.out.print("\n Value of % :"+(2.3 % 2.3));
	}

	public static void eval(List<Integer> list, Predicate<Integer> predicate) {
		for(Integer n: list) {
			if(predicate.test(n)) {
				System.out.println(n + " ");
			}
		}
	}
	interface Message{
		void sayMessage(String str);
	}
	interface Operation{
		int operate(int a, int b);
	}
	int operate(int a, int b, Operation op){
		return op.operate(a, b);
	}
}
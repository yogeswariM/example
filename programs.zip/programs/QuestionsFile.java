package programs;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class QuestionsFile {
	List<String> questions = new ArrayList<String>();
	List<String> answers = new ArrayList<String>();
	ArrayList<String[]> options = new ArrayList<String[]>();
	List<String> questionsList = new ArrayList<String>();
	List<String> answersList = new ArrayList<String>();
	ArrayList<String[]> optionsList = new ArrayList<String[]>();

	public List<String> QuestionsList(int count,String language){
		String fileName = "";
		if(language.equals("C")){
			fileName = "D:\\Questions\\c.txt";
		}else if(language.equals("C++")){
			fileName = "D:\\Questions\\c++.txt";
		}else{
			fileName = "D:\\Questions\\java.txt";
		}
		try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
			String question = "",option = "";
			String sCurrentLine = null;
			while ((sCurrentLine = br.readLine()) != null) {
				question = sCurrentLine.substring(sCurrentLine.indexOf(')')+1, sCurrentLine.indexOf('@'));
				questions.add(question);
				option = sCurrentLine.substring(sCurrentLine.indexOf('@') + 1, sCurrentLine.indexOf('#'));
				String []choices = new String[4];
				choices = option.split("-");
				options.add(choices);
				answers.add(sCurrentLine.substring(sCurrentLine.indexOf('#')+1));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		int []array = new int[count];
		int i,ran=0,f=0;
		for(i=0;i<count;i++){
			array[i] = i;
		}
		ran=(int)(Math.random()*count);
		while(f != count){
			if(array[ran]==-1)
				ran=(int)(Math.random()*count);
			else{
				questionsList.add(questions.get(ran));
				optionsList.add(options.get(ran));
				answersList.add(answers.get(ran));
				array[ran]=-1;
				f++;
			}
		}
		return questionsList;
	}
	public ArrayList<String[]> getOptions(){
		return optionsList;
	}
	public List<String> getAnswers(){
		return answersList;
	}
}

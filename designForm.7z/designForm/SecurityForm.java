package com.designForm;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.*;
import java.io.FileNotFoundException;
import java.util.Enumeration;

import javax.swing.*;

public class SecurityForm extends JFrame implements ActionListener{
	private JLabel label,l1,l2,l3,l4,l5;
	private JButton b1,b2;
	private JRadioButton r1,r2,r3,r4,r5;
	private ButtonGroup bg;
	private String lang = "";
	
	public SecurityForm(){
		setLayout(null);
		setSize(500,250);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Get Started");
		label = new JLabel("Select number of questions");
		label.setBounds(20,10,300,25);
		label.setFont(new Font("Lucida Console", Font.BOLD, 15));
		add(label);

		r1= new JRadioButton("2",true);
		r1.setBounds(120,40,50,25);
		r1.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		r1.setOpaque(false);
		add(r1);

		r2= new JRadioButton("3");
		r2.setBounds(120,70,50,25);
		r2.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		r2.setOpaque(false);
		add(r2);

		r3= new JRadioButton("5");
		r3.setBounds(120,100,50,25);
		r3.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		r3.setOpaque(false);
		add(r3);
		

		bg=new ButtonGroup();
		bg.add(r1);
		bg.add(r2);
		bg.add(r3);
		
		b1=new JButton("Go");
		b1.setBounds(260,150,100,25);
		b1.setBackground(new Color(255, 255, 255));
		add(b1);
		b1.addActionListener(this);
		
		b2=new JButton("Back");
		b2.setBounds(370,150,100,25);
		b2.setBackground(new Color(255, 255, 255));
		add(b2);
		b2.addActionListener(this);
		
		setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		String selected="";
		dispose();
		if(e.getSource()== b1){
			for(Enumeration<AbstractButton> button=bg.getElements();button.hasMoreElements();){
				AbstractButton rb=button.nextElement();
				if(rb.isSelected()){
					selected=rb.getText();
					break;
				}
			}
			try {
				new SecurityQuestions(selected);
			} catch (NumberFormatException e1) {
				e1.printStackTrace();
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}else{
			new frameDesign("LOGIN");
		}
	}

}

package com.designForm;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ResultPage implements ActionListener{
	JFrame frame;
	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
	JButton b1;
	QuestionsFile q = new QuestionsFile();
	String performance;
	int c = 0, w = 0, u = 0, total = 0, i = 0, size = 0;
	int count = 0;
	public ResultPage(List<String> answerList,List<String> correctList){
		size = answerList.size();
		for(i = 0;i < size;i++){
			if(answerList.get(i).isEmpty()) u++;
			else{
				c += answerList.get(i).equals(correctList.get(i)) ? 1 : 0;
				w += answerList.get(i).equals(correctList.get(i)) ? 0 : 1;				
			}
			total = c - w;
		}
		frame = new JFrame("DETAILS");
		frame.setBounds(500,300,400,300);
		frame.setLayout(null);
		
		l1 = new JLabel("TEST NAME ");
		l1.setBounds(30,30,150,25);
		frame.add(l1);
		l2 = new JLabel(" ONLINE TEST");
		l2.setBounds(200,30,150,25);
		frame.add(l2);
		l3 = new JLabel("CORRECT ANSWERS ");
		l3.setBounds(30,60,150,25);
		frame.add(l3);
		l4 = new JLabel(": " + c);
		l4.setBounds(200,60,150,25);
		frame.add(l4);
		l5 = new JLabel("WRONG ANSWERS ");
		l5.setBounds(30,90,150,25);
		frame.add(l5);
		l6 = new JLabel(": " + w);
		l6.setBounds(200,90,150,25);
		frame.add(l6);
		l7 = new JLabel("UNANSWERED");
		l7.setBounds(30,120,150,25);
		frame.add(l7);
		l8 = new JLabel(": " + u);
		l8.setBounds(200,120,150,25);
		frame.add(l8);
		l9 = new JLabel("TOTAL MARKS");
		l9.setBounds(30,150,150,25);
		frame.add(l9);
		l10 = new JLabel(": " + total);
		l10.setBounds(200,150,150,25);
		frame.add(l10);
		l11 = new JLabel("PERFORMANCE");
		l11.setBounds(30,180,150,25);
		frame.add(l11);
		count = Integer.parseInt(ShowModal.count);
		if(c <= count && c >= count - 3){
			performance = "EXCELLENT !!!";
		}else if(c > count / 2 && c < count - 4){
			performance = "GOOD !!";
		}else if(c <= count / 4){
			performance = "NOT ENOUGH !!!";
		}else{
			performance = "FAIR !";
		}
		l12 = new JLabel(": " + performance);
		l12.setBounds(200,180,150,25);
		frame.add(l12);
		
		b1 = new JButton("OK");
		b1.setBounds(250,210,75,25);
		frame.add(b1);
		b1.addActionListener(this);
		
		frame.getContentPane().setBackground(new Color(230, 255, 179));
		frame.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("OK")){
			frame.dispose();
		}
	}
}

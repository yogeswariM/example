package com.designForm;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class design extends JFrame implements ActionListener {

	private JLabel entername;
	private JButton b1,b2;
	private String surname; 
	public static void main(String[] args) {
		design d= new design();
		d.setVisible(true);
	}

	public design(){
		setLayout(null);
		setSize(300,250);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		entername=new JLabel(" WELCOME ");
//		name= new JTextField();
		b1=new JButton("Register");
		b2=new JButton("Sign In");
		entername.setBounds(60,30,120,30);
//		name.setBounds(60,30,130,30);
		b1.setBounds(30,120,100,30);
		b2.setBounds(160,120,100,30);
		b1.addActionListener(this);
		b2.addActionListener(this);
		add(b1);
		add(b2);
//		add(name);
		add(entername);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b1){
			System.out.println("vdhvj");
//			surname=name.getText();
			surname=b1.getText();
//			JOptionPane.showMessageDialog(null,"Hello "+surname);
//			JOptionPane.showConfirmDialog(null,"R u Sure U want to enter ");
		}else{
			surname=b2.getText();	
		}
		dispose();
		new frameDesign(surname);
	}

}

package com.designForm;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class QuestionsFile {
	List<String> questionList=new ArrayList<String>();
	List<String[]> options=new ArrayList<String[]>();
	List<String> answers=new ArrayList<String>();
	List<String> questionStringList=new ArrayList<String>();
	ArrayList<String[]> optionList=new ArrayList<String[]>();
	List<String> answerList=new ArrayList<String>();
	public  List<String> QuestionList(int count) throws FileNotFoundException{
		String file="";
		file="D:\\questions.txt";
		BufferedReader br = new BufferedReader(new FileReader(file));
			String question="",option="",answer="";
			String selLine=null;
			try {
				while((selLine=br.readLine())!=null){
					question = selLine.substring(selLine.indexOf(')')+1, selLine.indexOf('?')+1);
					option = selLine.substring(selLine.indexOf('?')+1, selLine.indexOf('#'));
					answer=selLine.substring(selLine.indexOf('#')+1);
					String[]choices= new String[3];
					choices=option.split("-");
					questionList.add(question);
					options.add(choices);
					answers.add(answer);
//					System.out.println(questionList);
//					System.out.println(options);
//					System.out.println(answers);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			int[] array=new int[count];
			int i,ranno=0,cnt=0;
			for(i=0;i<count;i++){
				array[i]=i;
			}
			System.out.println(array);
			ranno=(int) (Math.random()*count);
			System.out.println(ranno);
			while(cnt!=count){
				if(array[ranno]!=-1){
					questionStringList.add(questionList.get(ranno));
					optionList.add(options.get(ranno));
					answerList.add(answers.get(ranno));
					array[ranno]=-1;
					cnt++;
				}else{
					ranno=(int) (Math.random()*count);	
				}
			}
		return questionStringList;
	}
	public ArrayList<String[]> getOptions(){
		return optionList;
	}
	public List<String> getAnswers(){
		return answerList;
	}
}

package com.designForm;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

	public class frameDesign extends JFrame implements ActionListener{
		private JLabel fname,lname,mailid,uname,pswd;
		private JTextField t1,t2,t3,t4,t5;
		private JRadioButton b1,b2;
		private JButton mb1,mb2;
		 static String surname;
	
		public frameDesign(String selected){
			if(selected=="Register"){
				setLayout(null);
				setSize(500,250);
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				setTitle("Register Page");
				fname=new JLabel(" FirstName ");
				fname.setBounds(50,30,100,30);
				add(fname);
				lname=new JLabel(" LastName ");
				lname.setBounds(50,70,100,30);
				add(lname);
				mailid=new JLabel(" mailid ");
				mailid.setBounds(50,110,100,30);
				add(mailid);
				t1=new JTextField();
				t1.setBounds(160,30,150,30);
				add(t1);
				t2=new JTextField();
				t2.setBounds(160,70,150,30);
				add(t2);
				t3=new JTextField();
				t3.setBounds(160,110,150,30);
				add(t3);
				mb1=new JButton("SUBMIT");
				mb1.setBounds(350,150,100,30);
				mb1.addActionListener(this);
				add(mb1);
			}else{
				setLayout(null);
				setSize(300,250);
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				setTitle("Login Page");
				uname=new JLabel(" UserName ");
				uname.setBounds(30,30,100,30);
				add(uname);
				pswd=new JLabel(" Password ");
				pswd.setBounds(30,90,100,30);
				add(pswd);
				t4=new JTextField();
				t4.setBounds(120,30,150,30);
				add(t4);
				t5=new JPasswordField();
				t5.setBounds(120,90,150,30);
				add(t5);
				mb2=new JButton("LOGIN");
				mb2.setBounds(60,150,100,30);
				mb2.addActionListener(this);
				add(mb2);
			}
//			getContentPane().setBackground(new Color(231, 255, 179));
			setVisible(true);
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()== mb1){
				dispose();
				new frameDesign("LOGIN");
			}else{
				dispose();
				new SecurityForm();
			}
		}
		
	}
		
		


package com.designForm;

import java.util.Enumeration;
import java.awt.event.*;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;

import javax.swing.*;

public class SecurityQuestions extends Thread implements ActionListener {
	String selected="";
	boolean selectedAnswer;
	JRadioButton r1,r2,r3,r4;
	static JLabel time;
	JButton quit;
	int loop=0;
	Timer timer;
	String[] choice;
	ButtonGroup bg;
	static JFrame f;
	JLabel questionNumber,question;
	static JButton next;
	static int seconds = ShowModal.time;
	List<String>questionList=new ArrayList<String>();
	List<String[]> arrayList=new ArrayList<String[]>();
	List<String>properList=new ArrayList<String>();
	List<String>answerList=new ArrayList<String>();
	QuestionsFile qJava = new QuestionsFile();
	public SecurityQuestions(String selected) throws NumberFormatException, FileNotFoundException {
		selected=selected;
		String q="";
		questionList=qJava.QuestionList(Integer.parseInt(selected));
		System.out.println(questionList);
		q=questionList.get(loop);
		arrayList=qJava.getOptions();
		properList=qJava.getAnswers();
		choice=arrayList.get(0);
		System.out.println(choice);
		timer=new Timer();
//		timer.
		Questions(q, 0,choice);
		
		System.out.println(arrayList);
		System.out.println(properList);
		System.out.println(choice);
		// TODO Auto-generated constructor stub
	}
	public SecurityQuestions() {
	}
//class callThread implements ActionListener{
//	SecurityQuestions qf = new SecurityQuestions();
//	int time=SecurityQuestions.seconds;
//	@Override
//	public void actionPerformed(ActionEvent e) {
//		// TODO Auto-generated method stub
//		
//	}
//	
//}
	
	public void Questions(String q,int flag,String[] arrayList){
		f = new JFrame("QUESTIONS");
		f.setBounds(500,300,700,350);
		f.setLayout(null);

		questionNumber = new JLabel("QUESTION : " + (flag + 1) + " / " + selected);
		questionNumber.setBounds(20,20,200,25);
		f.add(questionNumber);

		question = new JLabel(q);
		question.setBounds(20,70,650,25);
		f.add(question);
		
		time = new JLabel();
		time.setBounds(500,20,200,25);
		f.add(time);

		r1= new JRadioButton(arrayList[0]);
		r1.setBounds(120,110,500,25);
		f.add(r1);

		r2= new JRadioButton(arrayList[1]);
		r2.setBounds(120,140,500,25);
		f.add(r2);

		r3= new JRadioButton(arrayList[2]);
		r3.setBounds(120,170,500,25);
		f.add(r3);

		r1.setOpaque(false);
		r2.setOpaque(false);
		r3.setOpaque(false);
		
		bg = new ButtonGroup();
		bg.add(r1);
		bg.add(r2);
		bg.add(r3);

		next = new JButton("NEXT>>>");
		next.setBounds(450,250,100,25);
		next.addActionListener(this);
		f.add(next);

		quit = new JButton("QUIT");
		quit.setBounds(20,250,75,25);
		quit.addActionListener(this);
		f.add(quit);

//		f.getContentPane().setBackground(new Color(230, 255, 179));
		f.setVisible(true);
	}
	public void result(boolean b){
		if(b) JOptionPane.showMessageDialog(null, "TIME UP !!! \n CLICK SUBMIT TO SEE THE RESULT");
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getActionCommand().equals("QUIT")){
//			timer.stop();
			f.dispose();
		}
		if(e.getActionCommand().equals("NEXT>>>")){
			selectedAnswer = false;
			for(Enumeration<AbstractButton> buttons = bg.getElements();buttons.hasMoreElements();){
				AbstractButton rb = buttons.nextElement();
				if(rb.isSelected()){
					selectedAnswer = true;
					answerList.add(rb.getText());
					break;
				}
			}
			if(! selectedAnswer){
				answerList.add("");
			}
			bg.clearSelection();
			choice = arrayList.get(loop);
			if(loop < questionList.size()){
				question.setText(questionList.get(loop++));
				r1.setText(choice[0]);
				r2.setText(choice[1]);
				r3.setText(choice[2]);
				questionNumber.setText("QUESTION : " + loop + " / " + selected);
			}
			if(questionList.size() == loop)
				next.setText("SUBMIT");
		}
		if(e.getActionCommand().equals("SUBMIT")){
//			timer.stop();
			selectedAnswer = false;
			for(Enumeration<AbstractButton> buttons = bg.getElements();buttons.hasMoreElements();){
				AbstractButton rb = buttons.nextElement();
				if(rb.isSelected()){
					selectedAnswer = true;
					answerList.add(rb.getText());
					break;
				}
			}
			if(!selectedAnswer){
				answerList.add("");
			}
			if(loop != Integer.parseInt(selected)){
				while(loop++ != Integer.parseInt(selected))
					answerList.add("");
			}
			f.dispose();
			new ResultPage(answerList,properList);
		}
	}

}

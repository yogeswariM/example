package com.newSample;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
public class QuestionForm extends JFrame implements ActionListener {
	private JLabel lb1,lb2;
	private JRadioButton rb1,rb2,rb3;
	private JButton bt1,bt2;
	private ButtonGroup bg;
	boolean selected = false;
	int loop=0,cnt;
	static int time=20;
	static JLabel lb3;
	String[] ch;
	List<String> questionList=new ArrayList<String>();
	List<String[]> optionList=new ArrayList<String[]>();
	List<String> correctList=new ArrayList<String>();
	List<String> answerList=new ArrayList<String>();
	public QuestionForm(int count) throws IOException{
//		timerClass task=new timerClass(); 
		Timer t = new Timer(100,new timerClass() );
		t.start();
		String q="";
		cnt=count;
		QuestionClass qjava=new QuestionClass();
		questionList=qjava.QuestionFile(cnt);
		q=questionList.get(loop++);
		optionList=qjava.getOptions();
		correctList=qjava.getAnswers();
		ch=optionList.get(0);
		Questions(q, 0,ch);
	}
	public void Questions(String question,int flag,String[] arrayList){
		setLayout(null);
		setSize(500,250);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		lb1=new JLabel("Questions: "+ loop + " / " + cnt);
		lb1.setBounds(10,10,100,30);
		add(lb1);
		lb2=new JLabel(question);
		lb2.setBounds(30,30,200,30);
		add(lb2);
		lb3=new JLabel("Time : "+time+"secs");
		lb3.setBounds(150,10,200,30);
		add(lb3);
		rb1=new JRadioButton(arrayList[0]);
		rb1.setBounds(30,50,100,30);
		add(rb1);
		rb2=new JRadioButton(arrayList[1]);
		rb2.setBounds(30,70,100,30);
		add(rb2);
		rb3=new JRadioButton(arrayList[2]);
		rb3.setBounds(30,90,100,30);
		add(rb3);
		setVisible(true);
		bg=new ButtonGroup();
		bg.add(rb1);
		bg.add(rb2);
		bg.add(rb3);
		bt1=new JButton("Next");
		bt1.setBounds(80,150,100,30);
		add(bt1);
		bt1.addActionListener(this);
		setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand()=="Next"){
			selected = false;
			for(Enumeration<AbstractButton> buttons = bg.getElements();buttons.hasMoreElements();){
				AbstractButton rb = buttons.nextElement();
				if(rb.isSelected()){
					selected = true;
					answerList.add(rb.getText());
					break;
				}
			}
			if(! selected){
				answerList.add("");
			}
			bg.clearSelection();
			ch = optionList.get(loop);
			if(loop<questionList.size()){
				lb1.setText("QUESTION : " + (loop+1) + " / " + cnt);
				rb1.setText(ch[0]);
				rb2.setText(ch[1]);
				rb3.setText(ch[2]);
				lb2.setText(questionList.get(loop++));
			}
			if(loop==questionList.size()){
				bt1.setText("Submit");
			}
		}
		if(e.getActionCommand()=="Submit"){
			selected = false;
			for(Enumeration<AbstractButton> buttons = bg.getElements();buttons.hasMoreElements();){
				AbstractButton rb = buttons.nextElement();
				if(rb.isSelected()){
					selected = true;
					answerList.add(rb.getText());
					break;
				}
			}
			if(! selected){
				answerList.add("");
			}
			if(loop!= cnt){
				while(loop++ != cnt)
					answerList.add("");
			}
			dispose();
			new RemarkClass(answerList,correctList);
		}
	}
}
class timerClass implements ActionListener{
	QuestionForm qf;
	public timerClass(){
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		qf.lb3.setText((qf.time--)+" Seconds");
		if(qf.time == 0){
//			qf.time.stop();
			JOptionPane.showMessageDialog(null,"Time up");
		}
	}
}
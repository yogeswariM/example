package com.newSample;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Enumeration;
public class selectionForm extends JFrame implements ActionListener  {
	private JLabel lb1;
	private JRadioButton rb1,rb2,rb3;
	private JButton bt1,bt2;
	private ButtonGroup bg;
	public selectionForm(){
		setLayout(null);
		setSize(500,250);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		lb1=new JLabel("Select No.Of Questions");
		lb1.setBounds(30,30,150,30);
		add(lb1);
		rb1=new JRadioButton("2");
		rb1.setBounds(30,50,100,30);
		add(rb1);
		rb2=new JRadioButton("4");
		rb2.setBounds(30,70,100,30);
		add(rb2);
		rb3=new JRadioButton("5");
		rb3.setBounds(30,90,100,30);
		add(rb3);
		setVisible(true);
		bg=new ButtonGroup();
		bg.add(rb1);
		bg.add(rb2);
		bg.add(rb3);
		bt1=new JButton("Start");
		bt1.setBounds(80,150,100,30);
		add(bt1);
		bt1.addActionListener(this);
		bt2=new JButton("Back");
		bt2.setBounds(200,150,100,30);
		add(bt2);
		bt2.addActionListener(this);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bt1){
			int Numbr = 0;
			for(Enumeration<AbstractButton> button=bg.getElements();button.hasMoreElements();){
				AbstractButton selected= button.nextElement();
				if(selected.isSelected()){
					Numbr=Integer.parseInt(selected.getText());
					break;
				}
			}
			dispose();
			try {
				new QuestionForm(Numbr);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}else{
			dispose();
			new MainClass();
		}
		
	}
}

package com.newSample;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class QuestionClass {
 List<String> questionList=new ArrayList<String>();
 List<String> answerList=new ArrayList<String>();
 List<String[]> OptionList=new ArrayList<String[]>();
 List<String> questionpassList=new ArrayList<String>();
 List<String> answerpassList=new ArrayList<String>();
 ArrayList<String[]> OptionpassList=new ArrayList<String[]>();
	public List<String> QuestionFile(int count) throws IOException{
		String filenmae="";
		int i=0,ran=0,f=0;
		String question="",option="",answer="";
		String currentLine="";
		filenmae="D:\\questions.txt";
		BufferedReader br=new BufferedReader(new FileReader(filenmae));
		while((currentLine=br.readLine())!=null){
			question=currentLine.substring(currentLine.indexOf(')')+1, currentLine.indexOf('?')+1);
			questionList.add(question);
			option = currentLine.substring(currentLine.indexOf('?')+1, currentLine.indexOf('#'));
			answer=currentLine.substring(currentLine.indexOf('#')+1);
			answerList.add(answer);
			String [] choice= new String[4];
			choice =option.split("-");
			OptionList.add(choice);
		}
		int [] array=new int[count];
		for(i=0;i<count;i++){
			array[i] = i;
		}
		ran=(int) (Math.random()*count);
		while(f!=count){
			if(array[ran]!=-1){
				questionpassList.add(questionList.get(ran));
				answerpassList.add(answerList.get(ran));
				OptionpassList.add(OptionList.get(ran));
				array[ran]=-1;
				f++;
			}else{
				ran=(int) (Math.random()*count);
			}
		}
		return questionpassList;
		
	}
	public List<String[]> getOptions(){
		return OptionpassList;
	}
	public List<String> getAnswers(){
		return answerpassList;
	}
}

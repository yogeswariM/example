package com.newSample;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
public class RemarkClass extends JFrame implements ActionListener  {
	private JLabel lb1,lb2,lb3;
	private JButton bt1;
	int c=0,w=0,i=0,u=0,total=0;
	public RemarkClass(List<String> answerList,List<String> correctList){
		for(i = 0;i < answerList.size();i++){
			if(answerList.get(i).isEmpty()) u++;
			else{
				c += answerList.get(i).equals(correctList.get(i)) ? 1 : 0;
				w += answerList.get(i).equals(correctList.get(i)) ? 0 : 1;				
			}
			total = c - w;
		}
		setLayout(null);
		setSize(500,250);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		lb1=new JLabel("Correct:"+c);
		lb1.setBounds(150,10,100,30);
		add(lb1);
		lb2=new JLabel("Incorrect:"+w);
		lb2.setBounds(150,10,100,30);
		add(lb2);
		lb3=new JLabel("Total Marks:"+total);
		lb3.setBounds(150,10,100,30);
		add(lb3);
		bt1=new JButton("Finish");
		bt1.setBounds(80,150,100,30);
		add(bt1);
		bt1.addActionListener(this);
		setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bt1){
			dispose();
		}
	}
}

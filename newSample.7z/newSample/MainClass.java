package com.newSample;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
public class MainClass extends JFrame implements ActionListener {

	private JLabel lb1;
	private JButton bt1,bt2;
	
	public MainClass(){
	setLayout(null);
	setSize(300,250);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	lb1=new JLabel("Test your IQ Level");
	lb1.setBounds(90,40,150,100);
	add(lb1);
	bt1=new JButton("Go");
	bt1.setBounds(50,150,100,20);
	bt1.addActionListener(this);
	add(bt1);
	bt2=new JButton("Exit");
	bt2.setBounds(160,150,100,20);
	bt2.addActionListener(this);
	add(bt2);
	setVisible(true);
	}
	public static void main(String[] args) {
		new MainClass();
	} 
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bt1){
			dispose();
			new selectionForm();
		}else{
			dispose();
		}
		
	}

}
